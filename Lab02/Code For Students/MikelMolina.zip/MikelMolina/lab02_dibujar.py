from to_draw import draw

def test():
   g  = [[0, 1, 1, 0, 0],
         [1, 0, 1, 1, 1],
         [1, 1, 0, 1, 1],
         [0, 1, 1, 0, 1],
         [0, 1, 1, 1, 0]]


   draw(g)
    
   
    
test()